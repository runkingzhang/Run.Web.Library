#如何关注IntelliJ IDEA动态

---

* **JetBrains在新浪微博**：http://weibo.com/3220313942 
* **JetBrains在Google+**：https://plus.google.com/+jetbrains/
* **JetBrains在Facebook**：http://www.facebook.com/JetBrains
* **JetBrains在Twitter**：http://twitter.com/#!/jetbrains
* **IntelliJ IDEA官网博客**：http://blog.jetbrains.com/idea/
* **其他注意细节**：IntelliJ IDEA博客支持RSS订阅，如果你不懂RSS，请看这个视频教程：[点击我](http://www.youmeek.com/use-rss-to-read-is-beautiful/ "@RSS的系统介绍+如何使用RSS进行订阅+阅读(视频教程)")

---

* **作者**：Judas.n [作者Blog](http://www.YouMeek.com "个人博客")
* **时间**：2013年12月14日 09:17:20
