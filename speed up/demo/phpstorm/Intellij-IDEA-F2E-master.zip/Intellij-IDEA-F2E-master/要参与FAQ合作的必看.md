#注意和准备

你clone项目下来之后,你会发现右侧Project结构里面没有FAQ文件夹,但是实际通过电脑的文件夹是可以看到有存在的.  
遇到这样的问题你需要如下图这样做（**需要注意的有下面两点，Gif截图一定要看**）：
* module名称必须是：`FAQ`
* 创建好module之后的FAQ.iml文件不要加入到版本控制里面,也不要提交  
* IntelliJ IDEA的markdown插件有点问题，有时候会自动帮你去掉空格，引起问题，建议用其他工具撰写md

---

![FAQ创建](http://external-img.b0.upaiyun.com/idea-faq.gif)
