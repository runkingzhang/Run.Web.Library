function foo(){return 42}function bar(){return 2*foo()}function baz(){return bar()*bar()}
//# sourceMappingURL=sourcemaps_multiple2.js.map