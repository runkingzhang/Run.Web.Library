function longFunctionC(a,b){return longNameA+longNameB+a+b}var longNameA=1,longNameB=2,result=longFunctionC(3,4);
//# sourceMappingURL=sourcemap_functionName.js.fn.map