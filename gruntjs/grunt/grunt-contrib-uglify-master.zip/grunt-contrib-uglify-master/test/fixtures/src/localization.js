var set = [
    "This is a random set of chαracters and strings.",
    "这是一组随机字符和字符串。",
    "Это случайный набор символов и строк",
    "Цé випадковий набір символів та рядків"
], answer = set[Math.floor(Math.random()*set.length)];