gcc -O2 -S -c hello.c
