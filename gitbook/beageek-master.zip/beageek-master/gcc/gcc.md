#GCC#


	#include<stdio.h>

	int main(){
	  printf("Hello,world");
	  return 0;
	}
	


    gcc -O2 -S -c hello.c

