
原文在 [be a geek 1:无处不在的html][1]

[1]:http://www.phodal.com/blog/be-a-geek-chapter-1-anywhere-html/