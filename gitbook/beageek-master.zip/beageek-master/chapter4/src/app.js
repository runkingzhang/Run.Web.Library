	function Calc(){

	}
	Calc.prototype.add=function(a,b){
		return a+b;
	};
	Calc.prototype.sub=function(a,b){
		return a-b;
	};
