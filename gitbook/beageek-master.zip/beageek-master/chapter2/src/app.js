var para = document.getElementById("para");
para.style.color = "blue";