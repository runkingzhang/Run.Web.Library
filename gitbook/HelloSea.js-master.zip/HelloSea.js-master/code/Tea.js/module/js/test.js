Bodule.use(['/js/greet'], function (require) {
    var Greet = require('/js/greet')
    Greet.helloJavaScript()
    Greet.helloLua()
})

