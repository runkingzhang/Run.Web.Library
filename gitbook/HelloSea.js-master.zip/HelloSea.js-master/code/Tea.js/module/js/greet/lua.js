Bodule.define('/js/greet/lua',[], function (require, exports, module) {
    module.exports = {
        helloLua:function () {
            console.log("Hello,Lua")
        } 
    }
})
