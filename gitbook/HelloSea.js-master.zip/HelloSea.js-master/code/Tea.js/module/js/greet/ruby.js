Bodule.define('/js/greet/ruby',[], function (require, exports, module) {
    module.exports = {
        helloRuby:function () {
            console.log("Hello,ruby")
        } 
    }
})

