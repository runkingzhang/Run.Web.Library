<?php
return array(
  'name' => '首页焦点图',
  'option' => true,
  'allow_type' => array('image'),
);