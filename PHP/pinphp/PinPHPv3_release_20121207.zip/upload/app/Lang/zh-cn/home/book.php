<?php

return array(
    'hot_tags' => '热门标签',
);
