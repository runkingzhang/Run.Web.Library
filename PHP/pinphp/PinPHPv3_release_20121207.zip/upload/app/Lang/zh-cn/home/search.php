<?php

return array(
	'search_no_content' => '抱歉，没有找到有关“%s”的搜索结果',
    'search_item_title' => '关于%s的分享',
    'search_album_title' => '关于%s的专辑',
    'search_user_title' => '关于%s的用户',
);
