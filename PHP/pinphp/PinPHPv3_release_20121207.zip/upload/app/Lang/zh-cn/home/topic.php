<?php

return array(
    'input_allow_limit' => '还可以输入',
    'cnwords' => '个汉字',
    'forward_invalid_topic' => '您要转发的微薄不存在或者已经被删除',
    'forward_success' => '转发成功',
    'forward_failed' => '转发失败',
    'please_input_comment_info' => '请输入评论内容！',
    'comment_invalid_topic' => '您要评论的微薄不存在或者已经被删除',
    'comment_success' => '评论成功',
    'comment_failed' => '评论失败',
    'please_select_comment' => '请选择要删除的评论！',
    'delete_comment_success' => '删除评论成功',
    'delete_comment_failed' => '删除评论失败',
    'please_select_delete_topic' => '请选择要删除的动态！',
    'delete_topic_success' => '删除成功！',
    'delete_topic_failed' => '删除失败',
);
