<?php
define('PINPHP_PATH', '../');
define('APP_NAME', 'uc');
define('APP_PATH', './uc/');
define('PIN_DATA_PATH', '../data/');
define('RUNTIME_PATH', PIN_DATA_PATH . 'runtime/uc/');
define('APP_DEBUG', true);
require("../_core/setup.php");